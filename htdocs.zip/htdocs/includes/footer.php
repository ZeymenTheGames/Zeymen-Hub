<script>lucide.createIcons();</script>
</body></html>